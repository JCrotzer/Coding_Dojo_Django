from django.apps import AppConfig


class TimeDisplay1Config(AppConfig):
    name = 'time_display1'
